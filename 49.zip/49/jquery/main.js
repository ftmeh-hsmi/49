const TODOS = JSON.parse(localStorage.getItem("todos")) ?? []
let editableItem;
let tryCount = 0


function updateLocalStorage() {
    localStorage.setItem("todos", JSON.stringify(TODOS))
}

function handleDeleteTodo(itemId) {
    debugger
    try {
        const foundIndex = TODOS.findIndex(item => item.id === itemId)
        TODOS.splice(foundIndex, 1)
        updateLocalStorage();
        renderTodos()
    } catch (error) {
        if (tryCount < 2) {
            tryCount++;
            handleDeleteTodo(itemId)
        } else {
            tryCount = 0
        }
    }
}

function handleEdit(itemId) {
    editableItem = itemId
    renderTodos()
}

function handleSave(itemId) {
    const inputVal = $("#editable-item-input").val()
    const foundIndex = TODOS.findIndex(item => item.id === itemId);
    TODOS[foundIndex].title = inputVal

    editableItem = null
    updateLocalStorage()
    renderTodos()
}

function renderTodos() {
    const template = TODOS.map((item) => {
        const { title, id } = item
        return `
                <li class="todo">
                    ${editableItem === id ? `<input id="editable-item-input" type="text" value="${title}" />` : `${title}`}
                    
                    <button onclick="handleDeleteTodo(${id})">delete</button>

                    ${editableItem === id ? `<button onclick="handleSave(${id})">save</button>` : `<button onclick="handleEdit(${id})">edit</button>`}
                </li>
            `
    }).join("")

    console.log(template)

    $("#root").html(template)
}

$("#add-btn").click(() => {
    const title = $("#input").val()
    const space = $("#space").val()

    const d = new Date()

    const newTodo = {
        title,
        space,
        id: d.getTime()
    }

    TODOS.push(newTodo)

    updateLocalStorage()

    renderTodos()
})



