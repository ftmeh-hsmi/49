

function handleSubmitForm(evt) {
    evt.preventDefault();

    const titleValue = document.getElementById("title").value
    const priceValue = document.getElementById("price").value
    const descValue = document.getElementById("description").value
    const catValue = document.getElementById("category").value
    const imgValue = document.getElementById("image").value

    fetch('https://fakestoreapi.com/products', {
        method: "POST",
        body: JSON.stringify(
            {
                titl: 'test product',
                price: 13.5,
                description: 'lorem ipsum set',
                image: 'https://i.pravatar.cc',
                category: 'electronic'
            }
        )
    })
        .then(res => res.json())
        .then(json => console.log(json))
}